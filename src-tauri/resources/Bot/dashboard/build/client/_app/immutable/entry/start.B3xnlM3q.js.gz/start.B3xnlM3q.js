import{l as o,a as r}from"../chunks/CuF6MoFF.js";export{o as load_css,r as start};
